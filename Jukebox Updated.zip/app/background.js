(function () {'use strict';

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var path = _interopDefault(require('path'));
var url = _interopDefault(require('url'));
var electron = require('electron');
var jetpack = _interopDefault(require('fs-jetpack'));

function createWindow (name, options) {

    var userDataDir = jetpack.cwd(electron.app.getPath('userData'));
    var stateStoreFile = 'window-state-' + name +'.json';
    var defaultSize = {
        width: options.width,
        height: options.height
    };
    var state = {};
    var win;

    var restore = function () {
        var restoredState = {};
        try {
            restoredState = userDataDir.read(stateStoreFile, 'json');
        } catch (err) {
            // For some reason json can't be read (might be corrupted).
            // No worries, we have defaults.
        }
        return Object.assign({}, defaultSize, restoredState);
    };

    var getCurrentPosition = function () {
        var position = win.getPosition();
        var size = win.getSize();
        return {
            x: position[0],
            y: position[1],
            width: size[0],
            height: size[1]
        };
    };

    var windowWithinBounds = function (windowState, bounds) {
        return windowState.x >= bounds.x &&
            windowState.y >= bounds.y &&
            windowState.x + windowState.width <= bounds.x + bounds.width &&
            windowState.y + windowState.height <= bounds.y + bounds.height;
    };

    var resetToDefaults = function (windowState) {
        var bounds = electron.screen.getPrimaryDisplay().bounds;
        return Object.assign({}, defaultSize, {
            x: (bounds.width - defaultSize.width) / 2,
            y: (bounds.height - defaultSize.height) / 2
        });
    };

    var ensureVisibleOnSomeDisplay = function (windowState) {
        var visible = electron.screen.getAllDisplays().some(function (display) {
            return windowWithinBounds(windowState, display.bounds);
        });
        if (!visible) {
            // Window is partially or fully not visible now.
            // Reset it to safe defaults.
            return resetToDefaults(windowState);
        }
        return windowState;
    };

    var saveState = function () {
        if (!win.isMinimized() && !win.isMaximized()) {
            Object.assign(state, getCurrentPosition());
        }
        userDataDir.write(stateStoreFile, state, { atomic: true });
    };

    state = ensureVisibleOnSomeDisplay(restore());

    win = new electron.BrowserWindow(Object.assign({}, options, state));

    win.on('close', saveState);

    return win;
}

// The variables have been written to `env.json` by the build process.
var env = jetpack.cwd(__dirname).read('env.json', 'json');

// This is main process of Electron, started as first thing when your
// app starts. This script is running through entire life of your application.
// It doesn't have any windows which you can see on screen, but we can open
// window from here.
var express = require('express'); // Express web server framework
var request = require('request'); // "Request" library
var querystring = require('querystring');
var cookieParser = require('cookie-parser');
var Repeat = require('repeat');
var res1 = {};
var ii = 1;
if (ii === 1) {
    var client_id = '71d18cb9b32c480d951eed41512df8fc'; // Your client id
    var client_secret = '2e89cb3f772345279ae54fa417cc7457'; // Your secret
    var redirect_uri = 'http://localhost:8080/callback/'; // Your redirect uri
}
else if (ii === 2) {
    var client_id = '71d18cb9b32c480d951eed41512df8fc'; // Your client id
    var client_secret = '2e89cb3f772345279ae54fa417cc7457'; // Your secret
    var redirect_uri = 'http://spartify.herokuapp.com/callback/'; // Your redirect uri
}
else if (ii === 3) {
    var client_id = '23fda62574464d50be2ecfd8540353b5'; // Your client id
    var client_secret = '44c1395c8390426d8b6b3f938f29af58'; // Your secret
    var redirect_uri = 'http://localhost:8080/callback/'; // Your redirect uri
}

var generateRandomString = function (length) {
    var text = '';
    var possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

    for (var i = 0; i < length; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
};
var nodeSpotifyWebHelper = require('node-spotify-webhelper');
var spotify = new nodeSpotifyWebHelper.SpotifyWebHelper();

// get the name of the song which is currently playing

var stateKey = 'spotify_auth_state';

var app1 = express();

app1.use(express.static(__dirname + '/authorization_code/public'))
   .use(cookieParser());

   app1.get('/login', function (req, res) {

       var state = generateRandomString(16);
       res.cookie(stateKey, state);

       // your app1lication requests authorization
       var scope = 'user-read-private user-read-email';
       res.redirect('https://accounts.spotify.com/authorize?' +
         querystring.stringify({
             response_type: 'code',
             client_id: client_id,
             scope: scope,
             redirect_uri: redirect_uri,
             state: state
         }));
   });

   app1.get('/choose-a-playlist', function (req, res) {
       res.redirect('/playlists.html');
   });
   app1.get('/details', function (req, res) {
       res.redirect('/welcome.html');
   });
   app1.get('/error', function (req, res) {
       res.redirect('/error.html');
   });
   app1.get('/callback', function (req, res) {

       // your app1lication requests refresh and access tokens
       // after checking the state parameter

       var code = req.query.code || null;
       var state = req.query.state || null;
       var storedState = req.cookies ? req.cookies[stateKey] : null;

       if (state === null || state !== storedState) {
           res.redirect('/#' +
             querystring.stringify({
                 error: 'state_mismatch'
             }));
       } else {
           res.clearCookie(stateKey);
           var authOptions = {
               url: 'https://accounts.spotify.com/api/token',
               form: {
                   code: code,
                   redirect_uri: redirect_uri,
                   grant_type: 'authorization_code'
               },
               headers: {
                   'Authorization': 'Basic ' + (new Buffer(client_id + ':' + client_secret).toString('base64'))
               },
               json: true
           };

           request.post(authOptions, function (error, response, body) {
               if (!error && response.statusCode === 200) {

                   var access_token = body.access_token,
                       refresh_token = body.refresh_token;
                   // console.log(body);
                   var options = {
                       url: 'https://api.spotify.com/v1/me',
                       headers: { 'Authorization': 'Bearer ' + access_token },
                       json: true
                   };

                   // use the access token to access the Spotify Web API
                   request.get(options, function (error, response, body) {
                       console.log(body);
                   });

                   // we can also pass the token to the browser to make requests from there
                   res.redirect('/#' +
                     querystring.stringify({
                         access_token: access_token,
                         refresh_token: refresh_token
                     }));
               } else {
                   res.redirect('/#' +
                     querystring.stringify({
                         error: 'invalid_token'
                     }));
               }
           });
       }
   });

   app1.get('/refresh_token', function (req, res) {

       // requesting access token from refresh token
       var refresh_token = req.query.refresh_token;
       var authOptions = {
           url: 'https://accounts.spotify.com/api/token',
           headers: { 'Authorization': 'Basic ' + (new Buffer(client_id + ':' + client_secret).toString('base64')) },
           form: {
               grant_type: 'refresh_token',
               refresh_token: refresh_token
           },
           json: true
       };

       request.post(authOptions, function (error, response, body) {
           if (!error && response.statusCode === 200) {
               var access_token = body.access_token;
               res.send({
                   'access_token': access_token
               });
           }
       });
   });
   app1.get('/SorryCharlie', function (req, res) {
       res.redirect('http://jkbx.us/');
   });
   app1.get('/error', function (req, res) {
       res.redirect('/error.html');
   });
   var databaseURL = 'postgres://yotnkoupklgnce:PEI_Vz3Jnz8qebuxiSafxNHcrj@ec2-54-235-95-188.compute-1.amazonaws.com:5432/d6480t5vkn701i';
   var pg = require('pg');
   pg.defaults.ssl = true;

   var bodyParser = require('body-parser');

   app1.use(bodyParser.json());

   app1.use(bodyParser.urlencoded({
       extended: false
   }));
   var partyName;

   var updateSong = function (song, artist) {
     try {
               pg.connect(process.env.DATABASE_URL || databaseURL, function (err, client) {
                   if (err) { throw err; client.end();}
                   else if (partyName) {
                           try {
                             client
                             .query("update songupdate set artist = $1 where username in ($2)", [artist, partyName.toUpperCase()]);
                                   client
                                   .query("update songupdate set songname = $1 where username in ($2)", [song, partyName.toUpperCase()])
                                       .on('end', function (finalres) {
                                           if (err) { throw err; client.end();}
                                           else {
                                               console.log("CURL");
                                               client.end();
                                           }
                                           });
                                   }
        catch (exception) {
               console.log(exception);
           }
       }
       else {
         console.log("Nope");
       }
       });
       }
        catch (exception) {
               console.log(exception);
           }
           finally {
             pg.end();
           }
   }
   var currentSong = "";
   var currentArtist = "";
   var nowPlaying = function () {
     spotify.getStatus(function (err, res) {
     if (err) {
       return console.error(err);
     }
   currentSong = res.track.track_resource.name;
   currentArtist = res.track.artist_resource.name;
     console.info('now playing:',
       currentArtist, '-',
       currentSong);
   });
   }
   nowPlaying();
   var nowPlaying2 = function () {
     spotify.getStatus(function (err, res) {
     if (err) {
       return console.error(err);
     }
   if (currentSong != res.track.track_resource.name) {
     var artist =  res.track.artist_resource.name;
     var song =  res.track.track_resource.name;
     updateSong(song, artist);
     nowPlaying();
     console.info('currently playing:', artist, + ' : ' + song);
       }
   });
   }
   setInterval(function(){ nowPlaying2(); }, 1200);
   app1.post('/votes', function (request, response) {
       try {
           pg.connect(process.env.DATABASE_URL || databaseURL, function (err, client) {
               if (err) { throw err; client.end(); }
               else {
                   try {
                   if (request.body.userName) {
                       try {
                               client
                                   .query("select songname from songvotes where userid in ($1)", [request.body.userName])
                                   .on('end', function (finalres) {
                                       if (err) { throw err; client.end(); }
                                       else if (finalres.rows.length > 0) {
                                           res1 = {};
                                           res1["songs"] = JSON.stringify(finalres.rows[0].songname);
                                           response.send(res1);
                                           client.end();
                                       }
                                       else {
                                         client.end();
                                       }
                                     });
                               }
       catch (exception) {
           console.log(exception);
       }
   }
   }
    catch (exception) {
           console.log(exception);
       }
   }
   });
   }
    catch (exception) {
           console.log(exception);
       }
       finally {
         pg.end();
       }
       });

   app1.post('/checkPassword', function (request, response) {
       try {
           pg.connect(process.env.DATABASE_URL || databaseURL, function (err, client) {
               if (err) { throw err; client.end(); }
               else {
                   try {
                   if (request.body.password) {
                       try {
                               client
                                   .query("select distinct lastfm from users where lastfm in ($1)", [request.body.password])
                                   .on('end', function (finalres) {
                                       if (err) { throw err; client.end(); }
                                       else if (finalres.rows.length <= 0) {
                                           res1 = {};
                                           res1["success"] = JSON.stringify("SUCCESS");
                                           response.send(res1);
                                           client.end();
                                       }
                                       else if (finalres.rows.length > 0) {
                                           res1 = {};
                                           res1["failure"] = JSON.stringify("FAIL");
                                           response.send(res1);
                                           client.end();
                                       }
                                       else {
                                         client.end();
                                       }
                                     });
                               }
       catch (exception) {
           console.log(exception);
       }
   }
   }
    catch (exception) {
           console.log(exception);
       }
   }
   });
   }
    catch (exception) {
           console.log(exception);
       }
       finally {
         pg.end();
       }
   });

   app1.post('/songUpdate', function (request, response) {
           try {
               pg.connect(process.env.DATABASE_URL || databaseURL, function (err, client) {
                   if (err) { throw err; console.log(request.body); client.end();}
                   else {
                       try {
                       if (request.body.songTitle) {
                           try {
                                    client
                             .query("update songupdate set playlist = $1 where username in ($2)", [request.body.playlist, request.body.userName]);
                               client
                             .query("update songupdate set artist = $1 where username in ($2)", [request.body.artist, request.body.userName]);
                                   client
                                   .query("update songupdate set songname = $1 where username in ($2)", [request.body.songTitle, request.body.userName])
                                       .on('end', function (finalres) {
                                           if (err) { throw err; client.end();}
                                           else if (request.body.songTitle){
                                               console.log("CURL");
                                               console.log(request.body.songTitle);
                                               res1 = {};
                                               res1["songs"] = "SUCCESS";
                                               response.send(res1);
                                               client.end();
                                           }
                                           else {
                                             client.end();
                                           }
                                         });
                                   }
           catch (exception) {
               console.log(exception);
           }
       }
       }
        catch (exception) {
               console.log(exception);
           }
       }
       });
       }
        catch (exception) {
               console.log(exception);
           }
           finally {
             pg.end();
           }
       });

       app1.post('/songRefresh', function (request, response) {
               try {
                 partyName = request.body.lastFM;
                   pg.connect(process.env.DATABASE_URL || databaseURL, function (err, client) {
                       if (err) { throw err; client.end(); }
                       else {
                           try {
                               try {
                                   client
                                       .query("select * from songupdate where username in ($1)", [request.body.lastFM.toUpperCase()])
                                           .on('end', function (finalres) {
                                               if (err) { throw err; client.end(); }
                                               else if (finalres.rows.length > 0){
                                                   console.log(finalres.rows[0].songname);
                                                   res1 = {};
                                                   res1["songs"] = JSON.stringify(finalres.rows[0].songname);
                                                   res1["artist"] = JSON.stringify(finalres.rows[0].artist);
                                                   response.send(res1);
                                                   client.end();
                                               }
                                               else {
                                                 client.end();
                                               }
                                             });
                                       }
               catch (exception) {
                   console.log(exception);
               }
           }
            catch (exception) {
                   console.log(exception);
               }
           }
           });
           }
            catch (exception) {
                   console.log(exception);
               }
               finally {
                 pg.end();
               }
   });


   app1.post('/upVote', function (request, response) {
       try {
           pg.connect(process.env.DATABASE_URL || databaseURL, function (err, client) {
               if (err) { throw err; client.end(); }
               else {
                   try {
                   if (request.body.userName && request.body.party && request.body.song) {
                       try {
                           client
                           .query("UPDATE songvotes set songname = (songname || ($1) || ($2)) where userid in ($3)", [",  +", request.body.song, request.body.userName])
                           .on('end', function (res) {
                               console.log(res);
                               if (err) { throw err; client.end(); }
                               else {
                               client
                                   .query("select songname from songvotes where userid in ($1)", [request.body.userName])
                                   .on('end', function (finalres) {
                                       if (err) { throw err; client.end();}
                                       else if (finalres.rows.length > 0){
                                           var res1 = {};
                                           res1["songs"] = JSON.stringify(finalres.rows[0].songname);
                                           response.send(res1);
                                           client.end();
                                       }
                                       else {
                                         client.end();
                                       }
                                     });
                               }
                           });
                       }
                       catch (exception) {
                           console.log(exception);
                       }
                   }
       }
       catch (exception) {
           console.log(exception);
       }
       finally {
         pg.end();
       }
   }
   })
   }
   catch (e) {
     console.log(e);
   }
   });

   app1.post('/downVote', function (request, response) {
       try {
           pg.connect(process.env.DATABASE_URL || databaseURL, function (err, client) {
               if (err) { throw err; }
               else {
                   try {
                   if (request.body.userName && request.body.party && request.body.song) {
                       try {
                           client
                           .query("UPDATE songvotes set songname = (songname || ($1) || ($2)) where userid in ($3)", [",  -", request.body.song, request.body.userName])
                           .on('end', function (res) {
                               console.log(res);
                               if (err) { throw err; client.end; }
                               else {
                               client
                                   .query("select songname from songvotes where userid in ($1)", [request.body.userName])
                                   .on('end', function (finalres) {
                                       if (err) { throw err; client.end(); }
                                       else if (finalres.rows.length > 0){
                                           var res1 = {};
                                           res1["songs"] = JSON.stringify(finalres.rows[0].songname);
                                           response.send(res1);
                                           client.end();
                                       }
                                       else {
                                         client.end();
                                       }
                                     });
                               }
                           });
                       }
                       catch (exception) {
                           console.log(exception);
                       }
                   }
       }
       catch (exception) {
           console.log(exception);
       }
       finally {
         pg.end();
       }
   }
   })
   }
   catch (e) {
     console.log(e);
   }
   });

   app1.post('/clearVotes', function (request, response) {
       try {
           pg.connect(process.env.DATABASE_URL || databaseURL, function (err, client) {
               if (err) { throw err; client.end(); }
               else {
                   try {
                   if (request.body.userName) {
                       try {
                           client
                           .query("UPDATE songvotes set songname = ($1) where userid in ($2)", ["null", request.body.userName])
                           .on('end', function (res) {
                               console.log(res.rows);
                               if (err) {console.log(err); throw err; client.end(); }
                               else {
                               var object = {};
                               object["data"] = res.rows;
                               response.send(object);
                               client.end();
                               }
                           });
                       }
                       catch (exception) {
                           console.log(exception);
                       }
                   }
       }
       catch (exception) {
           console.log(exception);
       }
       finally {
         pg.end();
       }
   }
   });
   }
   catch (e) {
     console.log(e);
   }
   });

   app1.post('/', function (request, response) {
       try {
           pg.connect(process.env.DATABASE_URL || databaseURL, function (err, client) {
               if (err) { throw err; client.end(); }
               else {
                   try {
                       if (request.body.party) {
                           client
                           .query("select distinct * from users where party in ($1)", [request.body.party.toUpperCase()])
                           .on('end', function (res1) {
                               if (res1.rows.length > 0 && res1.rows[0].username != request.body.username) {
                                   var result = {};
                                   result["invalid"] = "Enter a different Party Password.";
                                   console.log(res1.rows[0] + "HERE");
                                   response.send(result);
                                   client.end();
                               }
                               else {
                                   client
                                       .query("select * from users where username in ($1)", [request.body.username])
                                       .on('end', function (responder) {
                                           try {
                                               if (request.body.party && responder.rows.length > 0 && request.body.playlist && request.body.access_token && request.body.lastFM && request.body.password && !request.body.search && request.body.refresh_token) {
                                                   try {
                                                     client
                                                .query("UPDATE songvotes SET partyname = $1 where userid in ($2)", [request.body.party, request.body.username]);
                                                client
                                               .query("UPDATE songupdate SET username = $1 where userid in ($2)", [request.body.lastFM.toUpperCase(), request.body.username]);
                                               client
                                               .query("UPDATE songupdate SET playlist = $1 where userid in ($2)", [request.body.playlist, request.body.username]);
                                                 client
                                                       .query("UPDATE users SET lastfm = $1 where username in ($2)", [request.body.lastFM.toUpperCase(), request.body.username]);
                                                       client
                                                       .query("UPDATE users SET superpowers = $1 where username in ($2)", [request.body.password, request.body.username]);
                                                       client
                                                           .query("UPDATE users SET explicit = $1 where username in ($2)", [request.body.explicit, request.body.username]);
                                                       client
                                                               .query("UPDATE users SET access_token = $1 where username in ($2)", [request.body.access_token, request.body.username]);
                                                       client
                                                               .query("UPDATE users SET playlist = $1 where username in ($2)", [request.body.playlist, request.body.username]);
                                                       client
                                                               .query("UPDATE users SET refresh_token = $1 where username in ($2)", [request.body.refresh_token, request.body.username]);
                                                       client
                                                               .query("UPDATE users SET party = $1 where username in ($2)", [request.body.party.toUpperCase(), request.body.username])
                                                               .on('end', function (res) {
                                                                   console.log(res);
                                                                   if (err) { throw err; client.end(); } else {
                                                                       var results = "Hello fellow coders!!";
                                                                       response.send(results);
                                                                       client.end();
                                                                   }
                                                               });
                                                   }
                                                   catch (exception) {
                                                       console.log(exception);
                                                   }
                                               }
                                               else if (request.body.party && request.body.username && request.body.playlist && request.body.lastFM && request.body.password && !request.body.search && request.body.refresh_token) {
                                                   try {
                                                     client
                                                     .query("INSERT INTO songupdate values($1, $2, $3, $4, $5)", [request.body.lastFM.toUpperCase(), "firstEntry", "secondEntry", request.body.username, request.body.playlist]);
                                                     client
                                                     .query("INSERT INTO songvotes values($1, $2, $3)", ["firstEntry", request.body.username, request.body.party]);
                                                       client
                                                               .query("INSERT INTO users values($1, $2, $3, $4, $5, $6, $7, $8)", [request.body.party.toUpperCase(), request.body.access_token, request.body.lastFM, request.body.username, request.body.playlist, request.body.explicit, request.body.password, request.body.refresh_token])
                                                               .on('end', function (res) {
                                                                   console.log(res);
                                                                   if (err) { throw err; client.end(); }
                                                                   else {
                                                                       var results = "Hello fellow coders!!";
                                                                       response.send(results);
                                                                       client.end();
                                                                   }
                                                               });
                                                   }
                                                   catch (exception) {
                                                       console.log(exception);
                                                   }
                                               }
                                           }
                                           catch (exception) {
                                               console.log(exception);
                                           }
                                       });
                               }
                           });
                       }
                       else {
                           try {
                               client
                                   .query("select * from users where party in ($1)", [request.body.search.toUpperCase()])
                                   .on('end', function (res) {
                                       if (err) { throw err; client.end(); }
                                       else {
                                           var result = {};
                                           if (res.rows[0]) {
                                               result["password"] = JSON.stringify(res.rows[0].superpowers);
                                               result["access_token"] = JSON.stringify(res.rows[0].access_token);
                                               result["lastFM"] = JSON.stringify(res.rows[0].lastfm.toUpperCase());
                                               result["partyID"] = JSON.stringify(res.rows[0].party);
                                               result["username"] = JSON.stringify(res.rows[0].username);
                                               result["playlist"] = JSON.stringify(res.rows[0].playlist);
                                               result["explicit"] = JSON.stringify(res.rows[0].explicit);
                                               result["refresh_token"] = JSON.stringify(res.rows[0].refresh_token);
                                               response.send(result);
                                               client.end();
                                           }
                                       }
                                   });
                           }
                           catch (exception) {
                               console.log(request);
                           }
                       }
                   }
                   catch (exception) {
                       console.log(exception);
                   }
               }
           });
       }
       catch (exception) {
           console.log(exception);
       }
       finally {
           pg.end();
       }
   });



if (ii === 1) {
    console.log('Listening on 8080');
    app1.listen(process.env.PORT || 8080)
}
else if (ii === 2) {
    console.log('Listening on 5000');
    app1.listen(process.env.PORT || 5000)
}
else if (ii === 3) {
    console.log('Listening on 8080');
    app1.listen(process.env.PORT || 8080)
}

// Save userData in separate folders for each environment.
// Thanks to this you can use production and development versions of the app
// on same machine like those are two separate apps.
if (env.name !== 'production') {
    var userDataPath = electron.app.getPath('userData');
    electron.app.setPath('userData', userDataPath + ' (' + env.name + ')');
}
let myWindow = null;

const shouldQuit = electron.app.makeSingleInstance((commandLine, workingDirectory) => {
  // Someone tried to run a second instance, we should focus our window.
  if (myWindow) {
    if (myWindow.isMinimized()) myWindow.restore()
    myWindow.focus()
  }
});

if (shouldQuit) {
  electron.app.quit()
}

electron.app.on('ready', function () {
  //  setApplicationMenu();

    var mainWindow = createWindow('main', {
        width: 1000,
        height: 600
    });

    mainWindow.loadURL(url.format({
        pathname: path.join('localhost:8080/thank-you-host.html'),
        protocol: 'http',
        slashes: true
    }));
mainWindow.setMenu(null);
    if (env.name === 'development') {
       mainWindow.openDevTools();
    }
});

electron.app.on('window-all-closed', function () {
    electron.app.quit();
});

process.on('uncaughtException', function (error) {
console.log(error)
});
}());
//# sourceMappingURL=background.js.map