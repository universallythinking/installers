# SpotifyJukebox

1. Download and install Node.js
2. Clone Project
3. CD into project directory
4. npm install
5. npm test
6. Visit localhost:8080 in Chrome ( OR ) Safari
7. Click "Host a Party"
8. Sign in to Spotify
9. Choose playlist
10. Set party details
11. To allow others to "upvote" songs all the way to the top, have them enter the party password + "." in the song / artist search box...  Example: for the password "HERO", have them enter "HERO." in the search box.
12. Special commands you can enter in the search box...
    "Leave Party."
    "Logout."
    "Admin."
    "Full Screen."
    "Reload."
13. Unzip the corresponding .ZIP file in the "Cache Buster" directory and double click the "CacheBuster" file (either .EXE for Windows, or the Script file on MacOS...).
