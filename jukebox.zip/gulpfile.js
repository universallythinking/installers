'use strict';

require('./tasks/build_app');
require('./tasks/build_tests');
require('./tasks/start');
